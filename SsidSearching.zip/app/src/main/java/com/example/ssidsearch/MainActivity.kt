package com.example.wifisignal

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var wifiManager: WifiManager
    private lateinit var resultsContainer: LinearLayout
    private lateinit var refreshButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Create a ScrollView for the results
        val scrollView = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }

        // Create a container for the results
        resultsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }
        scrollView.addView(resultsContainer)

        // Create and add a Button to refresh signal strength
        refreshButton = Button(this).apply {
            text = "Refresh WiFi List"
            setOnClickListener {
                startWifiScan()
            }
        }

        // Create the main layout and add the button and scroll view
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(refreshButton)
            addView(scrollView)
        }

        // Set the programmatically created layout as the content view
        setContentView(layout)

        // Initialize WiFiManager
        wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

        // Request permissions
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                1
            )
        } else {
            registerReceiver()
            startWifiScan()
        }
    }

    private val wifiScanReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val success = intent.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED, false)
            if (success) {
                displayScanResults()
            } else {
                Toast.makeText(context, "WiFi Scan Failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun registerReceiver() {
        val intentFilter = IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
        registerReceiver(wifiScanReceiver, intentFilter)
    }

    private fun startWifiScan() {
        if (!wifiManager.isWifiEnabled) {
            Toast.makeText(this, "WiFi is disabled... enabling it", Toast.LENGTH_LONG).show()
            wifiManager.isWifiEnabled = true
        }

        wifiManager.startScan()
    }

    private fun displayScanResults() {
        // Clear previous results
        resultsContainer.removeAllViews()

        val scanResults = wifiManager.scanResults
        if (scanResults.isEmpty()) {
            val noResultsText = TextView(this).apply {
                text = "No WiFi networks found."
                textSize = 18f
            }
            resultsContainer.addView(noResultsText)
        } else {
            scanResults.forEach { result ->
                val textView = TextView(this).apply {
                    text = "SSID: ${result.SSID}, Signal: ${result.level} dBm"
                    textSize = 16f
                }
                resultsContainer.addView(textView)
            }
        }
    }
}
